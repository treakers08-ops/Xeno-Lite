# XenoLite Chromebook-Ready

This repo contains all necessary scripts for the Xenoverse-style VR demo and a GitHub Actions workflow to build an Android APK from Chromebook.

## Steps for Chromebook

1. Open your GitHub repo → Add file → Upload files.
2. Drag everything inside this ZIP:
   - `Assets_Scripts/` (all scripts)
   - `unity-android-build.yml`
   - `README_CI.md`
3. Commit changes.
4. Add repository secrets:
   - `UNITY_EMAIL` — your Unity account email
   - `UNITY_PASSWORD` — your Unity account password
5. Go to **Actions tab** → Unity Android Build → Run workflow.
6. Download the artifact `xeno-lite-apks.zip` when workflow finishes.
7. Install APK on Quest 2 via SideQuest Web.
